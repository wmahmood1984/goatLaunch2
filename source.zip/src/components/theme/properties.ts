export const THEME_PROPERTY = "theme";

export enum THEMES {
  DARK = "dark",
  LIGHT = "light",
}
