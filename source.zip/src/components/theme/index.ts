import ColorsEnum from "./colors";

export * from "./properties";

export { ColorsEnum };
